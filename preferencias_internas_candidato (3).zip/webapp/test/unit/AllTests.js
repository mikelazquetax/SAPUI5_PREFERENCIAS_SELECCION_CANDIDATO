sap.ui.define([
	"maz_renfe/preferencias_internas_candidato/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ushell/services/UserInfo",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/m/MessageToast",
	"sap/ui/core/ListItem",
	"sap/ui/core/routing/History",
	"sap/ui/core/UIComponent",
], function (Controller, UserInfo, Filter, FilterOperator, UriParameters, MessageBox, MessageToast, ListItem, History, UIComponent) {
	"use strict";
	var idJobApplication = '';
	var idJobRequisition = '';
	var arrayPlazasSeleccionadas = [];
	var MessageTriggered = '';
	var minPlaza = '';
	var maxPlaza = ''; 
	var fechaActual = '';
	var fechaFin = ''

	return Controller.extend("maz_renfe.preferencias_internas_candidato.controller.MainView", {
		onInit: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this)

			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.getRoute("MainView").attachPatternMatched(this._onObjectMatched, this);

			//Lo primero es recuperar el usuario de SuccessFactors que utiliza la app

		},

		_onObjectMatched: async function (oEvent) {
			return new Promise((resolve, reject) => {
				this.idJobApplication = window.decodeURIComponent(oEvent.getParameter('arguments').id);
				this.idJobRequisition = window.decodeURIComponent(oEvent.getParameter('arguments').idJobRequisition);

				this.callRenfeHana(this.idJobRequisition)
				resolve(true)

			})
		},

		callRenfeHana: function (jobReqID) {

			var oJSONModel = new sap.ui.model.json.JSONModel({
				"name": "",
				"candidateID": "",
				"DNI": "",
				"candidature": "",
				"instrucciones": ""
			});

			this.getView().setModel(oJSONModel, "jsonBasicData");

			var datosBasicosUser = this.getView().getModel("jsonBasicData").getData();
			datosBasicosUser.candidature = this.idJobApplication;
			this.getView().getModel("jsonBasicData").setData(datosBasicosUser);

			try {
				var userInfo = new sap.ushell.services.UserInfo();
				var user = userInfo.getId().toUpperCase();
			} catch (oError) {

				user = "6109771";

			}
			var oDataCandidate = this.getView().getModel();
			var that = this;

			$.ajax({
				url: "/odata/v2/CandidateLight?$filter=usersSysId%20eq%20%27" + user + "%27",
				type: "GET",
				dataType: "json",
				headers: {
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch",
					"Content-Type": "application/json; charset=utf-8"
				},
				async: true,
				success: function (result, status, response) {
					var odataResult = result;
					var datosBasicosUser = that.getView().getModel("jsonBasicData").getData();
					datosBasicosUser.name = (odataResult.d.results[0].firstName + " " + odataResult.d.results[0].lastName).toUpperCase();
					datosBasicosUser.candidateID = odataResult.d.results[0].candidateId;
					datosBasicosUser.DNI = odataResult.d.results[0].custIdentificationNumber;

					that.getView().getModel("jsonBasicData").setData(datosBasicosUser);
					//var idCandidato = datosBasicosUser.candidateID
					//	that.getJobRequisitions(odataArrayIdsCandidaturas, oViewx)

					//	that.callRenfeHana(that.idJobRequisition)

					var ModelRenfe = that.getView().getModel('renfe_hana');
					//	var that = this
					var objPlaza = {
						"JOBREQID": "",
						"MINVAL": "",
						"MAXVAL": "",
						"PLAZA": "",
						"DESCRIPCION": "",
						"FECHAS": ""
					}

					var arrayPlaza = {
						hardware: []
					}

					var oJSONModelVisibilidad = new sap.ui.model.json.JSONModel({
						visible: true
					})

					that.getView().setModel(oJSONModelVisibilidad, "jsonVisibilidad")

					var oJSONModelPlazas = new sap.ui.model.json.JSONModel({

					})

					that.getView().setModel(oJSONModelPlazas, "jsonPlazas")

					ModelRenfe.read('/ZrcmgrabarpreferenciasSet', {
						filters: [
							new Filter("JOBREQID", "EQ", jobReqID)
						],
						success: function (oData, response) {

							var ExtensionForm = that.getView().byId('combos');

							ExtensionForm.removeAllItems();

							oData.results.forEach((data) => {

								objPlaza.JOBREQID = data.JOBREQID
								objPlaza.MINVAL = data.MINVAL
								objPlaza.MAXVAL = data.MAXVAL
								objPlaza.PLAZA = data.PLAZA.replaceAll("-", " ")
								objPlaza.DESCRIPCION = data.DESCRIPCION
								objPlaza.FECHAS = data.FECHAS.split('- ')[1]
								datosBasicosUser.instrucciones = objPlaza.DESCRIPCION
								that.getView().getModel("jsonBasicData").setData(datosBasicosUser);
								arrayPlaza.hardware.push(objPlaza)
								that.minPlaza = objPlaza.MINVAL
								that.fechaFin = objPlaza.FECHAS
								that.maxPlaza = objPlaza.MAXVAL

								that.fechaActual = new Date().toString().split(' ')[2] + ' ' + new Date().toString().split(' ')[1] + '.' + ' ' + new Date()
									.toString().split(' ')[3]
									
								var anoActual = new Date().toString().split(' ')[3]
								var anoConv = that.fechaFin.split(' ')[2]
								
								console.log(fechaActual)

								if (that.fechaActual > that.fechaFin || anoConv < anoActual) {
									
									that.getView().getModel("jsonVisibilidad").setData({
										visible: false
									})
								}

								objPlaza = {}

							})
							console.log(arrayPlaza)
							that.getView().getModel("jsonPlazas").setData(arrayPlaza)
							var i = -1
							arrayPlaza.hardware.forEach((plaza) => {
								i++
								//comprobamos si existe.
								if (that.getView().byId(i.toString())){
									that.getView().byId(i.toString()).setValue("")
								}
								
								//Si existe la label la destruimos
								if(that.getView().byId(i.toString() + 'L' + that.idJobApplication)){
									that.getView().byId(i.toString() + 'L' + that.idJobApplication).destroy()
								}
								

								ExtensionForm.addItem(new sap.m.Text(that.getView().createId(i.toString() + 'L' + that.idJobApplication)), {

								});
								
								//Si existe el ComboBox lo destruimos
								if(that.getView().byId(i.toString())){
									that.getView().byId(i.toString()).destroy()
								}

								ExtensionForm.addItem(new sap.m.ComboBox(that.getView().createId(i.toString()), {
									items: {
										path: 'jsonPlazas>/hardware',
										template: new sap.ui.core.ListItem({

											text: '{jsonPlazas>PLAZA}'

										})

									},
									change: function (evento) {

										var idPlazaSeleccionada = evento.getSource().getId()

										var plazaSeleccionada = that.getView().byId(idPlazaSeleccionada).getValue()

										that.onChange(plazaSeleccionada, idPlazaSeleccionada, evento)

									}

								}))

								that.getView().byId(i.toString() + 'L' + that.idJobApplication).setText('Plaza Nº ' + (i + 1).toString())
								that.getView().byId(i.toString() + 'L' + + that.idJobApplication).addStyleClass('texto')
							})
							that.initialRead()

						},
						error: function () {

						}
					})

				},
				error: function (oError) {
					MessageBox.error('El candidato no tiene ninguna convocatoria');

				}
			});

		},

		onNavBack: function () {
			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();
			objetoApps.test = []
			//this.getView().getModel("tilesForCandidates").setData(objetoApps)

			if (sPreviousHash !== undefined) {
			//	window.history.go(-1);
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("prevView");
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("prevView");

			}
		},

		onChange: function (plazaSeleccionada, idPlazaSeleccionada, evento) {
			var that = this;
			var i = 0
			var ojbPlazasSeleccionadas = {
				"idPlazaSeleccionada": "",
				"plazaSeleccionada": ""
			}
			ojbPlazasSeleccionadas.idPlazaSeleccionada = parseInt(idPlazaSeleccionada.split('--')[2])
			ojbPlazasSeleccionadas.plazaSeleccionada = plazaSeleccionada

			var plazasAll = that.getView().getModel('jsonPlazas').getData()
			var nplazas = plazasAll.hardware.length
			var nplazasR = plazasAll.hardware.length - 1

			for (i = 1; i <= nplazas; i++) {
				var found = this.getView().byId((i - 1).toString()).getValue()
				if (found == plazaSeleccionada && ojbPlazasSeleccionadas.idPlazaSeleccionada !== (i - 1) && found !== "") {

					sap.m.MessageBox.warning('Plaza Duplicada - No se pueden repetir preferencias')
					this.getView().byId(idPlazaSeleccionada.split('--')[2]).setValue("")
					break
				}

			}

		},
		onSave: function () {
			var candidateId = this.getView().byId('candidateId').getText().split(': ')[1]
			var applicationId = this.getView().byId('applicationId').getText().split(': ')[1]
			var fullname = this.getView().byId('fullname').getText().split(': ')[1]
			var dni = this.getView().byId('dni').getText().split(': ')[1]

			var plazasAll = this.getView().getModel('jsonPlazas').getData()

			var plazasAlllength = plazasAll.hardware.length

			var i = 0
			var x = 0
			var y = 0

			for (let z of plazasAll.hardware) {
				var xPlaza = this.getView().byId(y.toString()).getValue()
				if (xPlaza !== "") {
					x++
				}
				y++
			}

			if (x < this.minPlaza || x > this.maxPlaza)  {
				sap.m.MessageBox.error('No puede seleccionar menos de ' + this.minPlaza + '  ni más de ' + this.maxPlaza + ' Plaza(s)')

			} else {

				plazasAll.hardware.forEach((plaza) => {
					var that = this
					var orden = i.toString()
					var selPlaza = that.getView().byId(i.toString()).getValue()

					if (selPlaza !== "") {
						x++
					}

					that.onRead(candidateId, applicationId, fullname, dni, selPlaza, orden).then(function (apto) {
						if (apto == true) {
							that.onUpdate(candidateId, applicationId, fullname, dni, selPlaza, orden)
						} else {
							that.onCreate(candidateId, applicationId, fullname, dni, selPlaza, orden)
						}

					})

					i++
				})
			}
			
		},

		onRead: async function (candidateId, applicationId, fullname, dni, plaza, orden) {
			var that = this
			return new Promise((resolve, reject) => {
				var ModelRenfe = that.getView().getModel('renfe_hana')

				ModelRenfe.read('/ZrcmpreferenciascandidatointernoSet', {
					filters: [
						new Filter("CANDIDATEID", "EQ", candidateId),
						new Filter("CANDIDATUREID", "EQ", applicationId),
						new Filter("ORDEN", "EQ", orden),
					],
					async: true,
					success: function (oData, response) {
						if (oData.results.length == 0) {
							resolve(false)
						} else {
							resolve(true)
						}
					},
					error: function (oERROR) {
						resolve(false)
					}
				})
			})

		},

		onCreate: function (candidateId, applicationId, fullname, dni, plaza, orden) {

			var record = {
				"CANDIDATEID": "",
				"CANDIDATUREID": "",
				"DNI": "",
				"FULLNAME": "",
				"PLAZA": "",
				"LAST_DATE": "",
				"ORDEN": ""
			}

			record.CANDIDATEID = candidateId;
			record.CANDIDATUREID = applicationId;
			record.FULLNAME = fullname;
			record.DNI = dni;
			record.PLAZA = plaza;
			record.LAST_DATE = (new Date()).toISOString().split('T')[0];
			record.ORDEN = orden
			var ModelRenfe = this.getView().getModel('renfe_hana')
			ModelRenfe.create('/ZrcmpreferenciascandidatointernoSet', record, {
				success: function () {
					sap.m.MessageToast.show('Preferencia Registrada')
				},
				error: function (oError) {
					console.log(record)
				}
			})

		},

		onUpdate: function (candidateId, applicationId, fullname, dni, plaza, orden) {

			var record = {
				"CANDIDATEID": "",
				"CANDIDATUREID": "",
				"DNI": "",
				"FULLNAME": "",
				"PLAZA": "",
				"LAST_DATE": "",
				"ORDEN": ""
			}

			record.CANDIDATEID = candidateId;
			record.CANDIDATUREID = applicationId;
			record.FULLNAME = fullname;
			record.DNI = dni;
			record.PLAZA = plaza;
			record.LAST_DATE = (new Date()).toISOString().split('T')[0];
			record.ORDEN = orden

			var path = "/ZrcmpreferenciascandidatointernoSet(CANDIDATEID='" + candidateId + "',CANDIDATUREID='" + applicationId + "',DNI='" +
				dni + "',ORDEN='" + orden + "')"
			var ModelRenfe = this.getView().getModel('renfe_hana')
			ModelRenfe.update(path, record, {
				success: function () {
					sap.m.MessageToast.show('Registro actualizado')
				},
				error: function (oError) {
					sap.m.MessageToast.show('Registro NO actualizado')
				}
			})

		},

		initialRead: function () {
			var that = this
			var candidateId = this.getView().byId('candidateId').getText().split(': ')[1]
			var applicationId = this.getView().byId('applicationId').getText().split(': ')[1]

			var plazasAll = this.getView().getModel('jsonPlazas').getData()

			var plazasAlllength = plazasAll.hardware.length

			var i = 0
			var ModelRenfe = that.getView().getModel('renfe_hana')
			plazasAll.hardware.forEach((plaza) => {
				var plazaoriginal = this.getView().byId(i.toString())
				ModelRenfe.read('/ZrcmpreferenciascandidatointernoSet', {
					filters: [
						new Filter("CANDIDATEID", FilterOperator.EQ, candidateId),
						new Filter("CANDIDATUREID", FilterOperator.EQ, applicationId),
						new Filter("ORDEN", FilterOperator.EQ, i)
					],
					async: true,
					success: function (oData, response) {
						plazaoriginal.setValue(oData.results[0].PLAZA)
					},
					error: function (oERROR) {

					}
				})
				i++
			})

		},

		onDelete: async function (candidateId, applicationId, fullname, dni, selPlaza, orden) {
			return new Promise((resolve, reject) => {

				var record = {
					"CANDIDATEID": "",
					"CANDIDATUREID": "",
					"DNI": "",
					"FULLNAME": "",
					"PLAZA": "",
					"LAST_DATE": "",
					"ORDEN": ""
				}

				record.CANDIDATEID = candidateId;
				record.CANDIDATUREID = applicationId;
				record.FULLNAME = fullname;
				record.DNI = dni;
				record.PLAZA = selPlaza;
				record.LAST_DATE = (new Date()).toISOString().split('T')[0];
				record.ORDEN = orden
				console.log(record)

				var path = "/ZrcmpreferenciascandidatointernoSet(CANDIDATEID='" + candidateId + "',CANDIDATUREID='" + applicationId +
					"',DNI='" +
					dni + "',ORDEN='" + orden + "')"
				var pathx = '/ZrcmpreferenciascandidatointernoSet'
				var ModelRenfe = this.getView().getModel('renfe_hana')
				ModelRenfe.remove(path, {
					method: 'DELETE',
					success: function () {
						sap.m.MessageToast.show('Registro actualizado')
						resolve(true)
					},
					error: function (oError) {
						sap.m.MessageToast.show('Registro NO actualizado')
						resolve(false)
					}
				})
			})
		},

	});
});
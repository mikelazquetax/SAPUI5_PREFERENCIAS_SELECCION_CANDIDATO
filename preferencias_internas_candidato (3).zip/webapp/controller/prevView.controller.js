sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ushell/services/UserInfo",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function (Controller, MessageBox, Filter, FilterOperator) {
	"use strict";
	var odataArrayIdsCandidaturas = [];
	window.objId = {};
	var pathJR = "/odata/v2/JobRequisition";
	window.objetoApps = {
		test: []
	};
	var arr = []

	var idJobRequisition = "";
	var x = 0;
	var y = 0

	return Controller.extend("maz_renfe.preferencias_internas_candidato.controller.prevView", {

		onInit: function () {

			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("prevView").attachPatternMatched(this._onRoutePatternMatched, this)
		//	this.onDataTable()
									x++
						console.log(x)
						if (x == 1) {
						//	this.onDataTable();
						}
				/*
											//Intentamos obtener el usuario conectado. Para ello tenemos que utilizar el parámetro UserInfo que lo instanciamos al utilizar el metod UserInfo de la libreria ushell
											//Para probar en test, ponemos la condicion de que si no recupera ningun usuario de logueo, nos traiga el usuario s0019566339.  Esto es solo mientras programamos
													try {
															var userInfo = new sap.ushell.services.UserInfo();
															var user = userInfo.getId().toUpperCase();
														} catch (oError) {

															user = '6109771';

														}

														var oModelProfileCandidate = new sap.ui.model.json.JSONModel(); //Estructura que tendrá nuestro modelo de tiles y que pintaremos en nuestra vista principal

														var path = "/odata/v2/CandidateLight";

														var odataArray = [];
														var odataArrayIdsCandidaturas = [];
														var idCandidato = '';
														var idJobRequisition
														var that = this;

														var oDatax = this.getView().getModel(); //Obtenemos nuestro Modelo CandidateLight que lo obtenemos del manifest y que lo creamos cuando nos conectamos al destination de SF

														that.getView().setBusy(true); // Puntitos de carga
														oDatax.read("/CandidateLight", {
															filters: [
																new Filter("usersSysId", "EQ", user)
															],
															async: true,
															success: function (oData, response) {
																var oViewx = that.getView();
																var odataResult = oData.results;
																odataArray.push(odataResult);
																idCandidato = '(' + odataArray[0][0].candidateId + 'L)'; //Obtenemos el ID DEL CANDIDATO
																oModelProfileCandidate.setData(odataResult);
																that.getView().setModel(oModelProfileCandidate, "profileCandidate");

																that.getCandidaturas(idCandidato, oViewx).then(function (apto) {
																	if (apto == true) {
																		//Tenemos todas las candidaturas de nuestro candidato. Ahora solo tenemos que filtar las que son
																		//internas de organización con preferencias. Para ello ejecutamos la funcion asyncrona getJobRequisitions
																		that.getJobRequisitions().then(function (apto) {
																			if (apto == true) {

																			}
																		})
																	}
																})

															},
															error: function (oError) {
																MessageBox.error('El usuario no tiene perfil de candidato');
															}
														});
								*/
		},

		_onRoutePatternMatched: function (oEvent) {
			if (oEvent.getParameter("name") === "prevView") {

			}
		},
		onAfterRendering: function (oEvent) {
			/*
						x++
						console.log(x)
						if (x == 1) {
							this.onDataTable();
						}*/
		},
				showc: function () {
				//	window.location.reload()
					this.onDataTable();
				},
		onDataTable: function () {
			try {
				this.getView().getModel("tilesForCandidates").getData()
				objetoApps.test = []
				this.getView().getModel("tilesForCandidates").setData(objetoApps)
			} catch (oError) {
				//	this.getView().getModel("tilesForCandidates").getData()
				objetoApps.test = []
					//	this.getView().getModel("tilesForCandidates").setData(objetoApps) 

			}

			try {
				var userInfo = new sap.ushell.services.UserInfo();
				var user = userInfo.getId().toUpperCase();
				console.log(user)
			} catch (oError) {

				user = '6109771';
				console.log(user)
			}

			var oModelProfileCandidate = new sap.ui.model.json.JSONModel(); //Estructura que tendrá nuestro modelo de tiles y que pintaremos en nuestra vista principal

			var path = "/odata/v2/CandidateLight";
			var path2 = '/odata/v2/CandidateLight?$filter=usersSysId%20eq%20%27' + user + '%27';
			var odataArray = [];
			var odataArrayIdsCandidaturas = [];
			var idCandidato = '';
			var idJobRequisition
			var that = this;

			var oDatax = this.getView().getModel(); //Obtenemos nuestro Modelo CandidateLight que lo obtenemos del manifest y que lo creamos cuando nos conectamos al destination de SF

			that.getView().setBusy(true); // Puntitos de carga

			$.ajax({
				url: path2,
				type: "GET",
				dataType: "json",
				headers: {
					"DataServiceVersion": "2.0",
					"X-CSRF-Token": "Fetch",
					"Content-Type": "application/json; charset=utf-8"
				},
				async: true,
				success: function (oData, response) {
					var oViewx = that.getView();
					var odataResult = oData.d.results;
					odataArray.push(odataResult);
					idCandidato = '(' + odataArray[0][0].candidateId + 'L)'; //Obtenemos el ID DEL CANDIDATO

					oModelProfileCandidate.setData(odataResult);
					that.getView().setModel(oModelProfileCandidate, "profileCandidate");

					that.getCandidaturas(idCandidato, oViewx).then(function (apto) {
						if (apto == true) {
							//Tenemos todas las candidaturas de nuestro candidato. Ahora solo tenemos que filtar las que son
							//internas de organización con preferencias. Para ello ejecutamos la funcion asyncrona getJobRequisitions
							that.getJobRequisitions().then(function (apto) {
								if (apto == true) {

								}
							})
						}
					})
				},
				error: function (oError) {
					MessageBox.error('El usuario no tiene perfil de candidato');
				}
			})

			/*			oDatax.read("/CandidateLight", {
							filters: [
								new Filter("usersSysId", "EQ", user)
							],
							async: true,
							success: function (oData, response) {
								var oViewx = that.getView();
								var odataResult = oData.results;
								odataArray.push(odataResult);
								idCandidato = '(' + odataArray[0][0].candidateId + 'L)'; //Obtenemos el ID DEL CANDIDATO

								oModelProfileCandidate.setData(odataResult);
								that.getView().setModel(oModelProfileCandidate, "profileCandidate");

								that.getCandidaturas(idCandidato, oViewx).then(function (apto) {
									if (apto == true) {
										//Tenemos todas las candidaturas de nuestro candidato. Ahora solo tenemos que filtar las que son
										//internas de organización con preferencias. Para ello ejecutamos la funcion asyncrona getJobRequisitions
										that.getJobRequisitions().then(function (apto) {
											if (apto == true) {

											}
										})
									}
								})

							},
							error: function (oError) {
								MessageBox.error('El usuario no tiene perfil de candidato');
							}
						});*/
		},

		getCandidaturas: async function (idCandidato, oViewx) {
			return new Promise((resolve, reject) => {
				var that = this;
				$.ajax({
					url: "/odata/v2/CandidateLight" + idCandidato + '/jobsApplied',
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						that.odataArrayIdsCandidaturas = result.d.results;
						resolve(true)
							//	that.getJobRequisitions(odataArrayIdsCandidaturas, oViewx)
					},
					error: function (oError) {
						MessageBox.error('El candidato no tiene ninguna convocatoria')
						resolve(false)
					}
				})
			})
		},

		getJobRequisitions: async function () {
			return new Promise((resolve, reject) => {
				var oModelApplications = new sap.ui.model.json.JSONModel({
					"test": [{
						"applicationId": "",
						"jobReqId": "",
						"custReferenceNumber": "",
						"jobTitle": "",

					}, ]
				});
				var that = this;

				that.odataArrayIdsCandidaturas.forEach((id) => {
					var idJobRequisition = '(' + id.jobReqId + 'L)'
					$.ajax({
						url: pathJR + idJobRequisition,
						type: "GET",
						dataType: "json",
						headers: {
							"DataServiceVersion": "2.0",
							"X-CSRF-Token": "Fetch",
							"Content-Type": "application/json; charset=utf-8"
						},
						async: true,
						success: function (result, status, response) {
							if (result.d.templateId == 503 || result.d.templateId == 446) {
								objId.custReferenceNumber = result.d.custReferenceNumber
								console.log(result.d.templateId)
								that.getNames(id, objId).then(function (apto) {
									if (apto === true) {
										console.log('hola')

										oModelApplications.setData(objetoApps)

										that.getView().setModel(oModelApplications, "tilesForCandidates")
										
										arr = that.getView().getModel("tilesForCandidates").getData().test
										
										var result = arr.reduce((unique, o) => {
											if (!unique.some(obj => obj.applicationId === o.applicationId)) {
												unique.push(o);
											}
											return unique;
										}, []);
										console.log(result)
										objetoApps.test = arr
										oModelApplications.setData(objetoApps)
										that.getView().setModel(oModelApplications, "tilesForCandidates")
										that.getView().setBusy(false)

									} else {
										return

									}
								})
								objId = {}

							}

						},
						error: function (oError) {

						}

					})
				})

			})
		},

		getNames: async function (id, objId) {
			return new Promise((resolve, reject) => {
				//	var that = this;
				this.idJobRequisition = '(' + id.jobReqId + 'L)'
				$.ajax({
					url: pathJR + this.idJobRequisition + '/jobReqLocale',
					type: "GET",
					dataType: "json",
					headers: {
						"DataServiceVersion": "2.0",
						"X-CSRF-Token": "Fetch",
						"Content-Type": "application/json; charset=utf-8"
					},
					async: true,
					success: function (result, status, response) {
						objId.jobTitle = result.d.results[0].jobTitle
						objId.applicationId = id.applicationId
						objId.jobReqId = id.jobReqId

						objetoApps.test.push(objId)
						objId = {}
						resolve(true)

					},
					error: function (oError) {
						resolve(false)
					}

				})
			})
		},

		onPress: function (evento) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var candidaturaSeleccionada = evento.getSource().getSubheader().split('/')
			oRouter.navTo("MainView", {
				id: candidaturaSeleccionada[0],
				idJobRequisition: candidaturaSeleccionada[1]
			});
		},

	});
});